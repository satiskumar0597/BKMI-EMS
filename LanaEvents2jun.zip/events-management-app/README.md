# Events Management App

The admin backend can be found here [Admin web backend repository](https://github.com/st3v3nmw/events-management-app-backend) \
It needs some more work, but...

## Screenshots

<img src="/screenshots/NoAuth.jpeg" height="768">

<img src="/screenshots/SignUp.jpeg" height="768">

<img src="/screenshots/Login.jpeg" height="768">

<img src="/screenshots/ForgotPassword.jpeg" height="768">

<img src="/screenshots/Discover.jpeg" height="768">

<img src="/screenshots/NotBooked.jpeg" height="768">

<img src="/screenshots/Booked.jpeg" height="768">

<img src="/screenshots/Scanning.png" height="768">
